<?php
$id = $_REQUEST['id'];
$model = new pembayaran();
$produk = $model->getPembayaran($id);

?>

<div class="container-fluid pt-4 px-4">
    <div class="col-sm-12 col-xl-10">
        <div class="bg-light rounded h-100 p-4">
            <h6 class="mb-4">Details Pembayaran</h6>
            <form>
                <div class="row mb-3">
                    <label for="kode" class="col-sm-4 col-form-label">Metode</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="kode" value="<?= $produk['metode']; ?>" disabled>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="nama" class="col-sm-4 col-form-label">total bayar</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="nama" value="<?= $produk['total_harga']; ?>" disabled>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="nama" class="col-sm-4 col-form-label">id pengirim</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="nama" value="<?= $produk['pengiriman_id']; ?>" disabled>
                    </div>
                </div>
                </div>
                <a href="index.php?url=Pages/pembayaran/dtpembayaran"><button type="button" class="btn btn-primary">Kembali</button></a>
            </form>
        </div>
    </div>